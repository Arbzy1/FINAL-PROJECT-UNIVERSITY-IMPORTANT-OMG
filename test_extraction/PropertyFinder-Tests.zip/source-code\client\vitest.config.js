export default {
  test: {
    environment: 'jsdom',
  },
};
