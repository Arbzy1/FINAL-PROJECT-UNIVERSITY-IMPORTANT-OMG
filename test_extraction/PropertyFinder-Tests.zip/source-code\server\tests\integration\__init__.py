# Test module initialization
